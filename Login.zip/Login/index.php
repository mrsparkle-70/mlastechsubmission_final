<?php

session_start();

if(!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !==true)
{
    header("location: login.php");
}


?>


<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

    <title>MLAS 2.0</title>
  </head>
  <body>
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <a class="navbar-brand" href="#">MLAS 2.0 user login</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNavDropdown">
    <ul class="navbar-nav">
      <li class="nav-item active">
        <a class="nav-link" href="#">Home <span class="sr-only">(current)</span></a>
      </li>
      <!-- <li class="nav-item">
        <a class="nav-link" href="register.php">Register</a>
      </li> -->
      <li class="nav-item">
        <a class="nav-link" href="login.php">Login</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="logout.php">Logout</a>
      </li>

      
     
    </ul>

  <div class="navbar-collapse collapse">
  <ul class="navbar-nav ml-auto">
  <li class="nav-item active">
        <a class="nav-link" href="#"> <img src="https://img.icons8.com/metro/26/000000/guest-male.png"> <?php echo "Welcome ". $_SESSION['username']?></a>
      </li>
  </ul>
  </div>


  </div>
</nav>

<!-- <div class="container mt-4">
<h3><?php echo "Welcome ". $_SESSION['username']?>!</h3> -->
<hr>
<body>
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <a class="navbar-brand" href="#"><img src="logotest.png" class="d-block w-100" alt="...">ML <strong> Accelerator 2.0
      </strong></strong></a>
    <h4><span class="badge badge-pill bg-light">COMING SOON !!</span></h4>

    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
      aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarSupportedContent">

      <ul class="navbar-nav mr-auto">
        <li class="nav-item active">
          <a class="nav-link" href="#">Home <span class="sr-only">(current)</span></a>
        </li>

        <li class="nav-item">
          <a class="nav-link" href="#about">About</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#glimpses">Glimpses<span class="sr-only"></span></a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#venue">Venue<span class="sr-only"></span></a>
        </li>

        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown"
            aria-haspopup="true" aria-expanded="false">
            Topics
          </a>
          <div class="dropdown-menu" aria-labelledby="navbarDropdown">
            <a class="dropdown-item" href="#">ARTIFICIAL INTELIGENCE</a>
            <a class="dropdown-item" href="#">MACHINE LEARNING</a>
            <div class="dropdown-divider"></div>
            <a class="dropdown-item" href="#">DEEP LEARNING</a>
            <a class="dropdown-item" href="#">&MORE</a>
          </div>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#contact">Contact Us</a>
        </li>


      </ul>
      <form class="form-inline my-2 my-lg-0">
        <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search">
        <button class="btn btn-outline-light my-2 my-sm-0" type="submit">Search</button>
      </form>
      <div class="mx-2">

        <button class="btn btn-danger" data-toggle="modal" data-target="#signupModal">Register for the Event</button>
      </div>
    </div>
  </nav>
  <!-- Sign Up Modal -->
  <div class="modal fade" id="signupModal" tabindex="-1" role="dialog" aria-labelledby="signupModalLabel"
    aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">&emsp;&emsp;&emsp;&emsp;&emsp;MLAS 2.0 User Registration
          </h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
          <!-- <img src="bg.jpg" alt="" class="avatar"> -->
          <!--<form name="contact" method="POST" data-netlify="true" onSubmit="Submit" data-nrtlify-honeypot="bot-field">
             <input class="d-none" name="bot-field">
            <div class="form-group">
              <label for="name">Your Name</label>
              <input type="text" class="form-control" id="name" name="name" aria-describedby="emailHelp">
              <small id="text" class="form-text text-muted"></small>
            </div>
                <div class="form-group">
                  <label for="exampleInputEmail1">Email address</label>
                  <input type="email" class="form-control" id="exampleInputEmail1" name="email" aria-describedby="emailHelp">
                  <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>
                </div>
                <div class="form-group">
                  <label for="exampleInputPassword1">Password</label>
                  <input type="password" class="form-control" id="exampleInputPassword1">
                </div>
                <div class="form-group">
                  <label for="cexampleInputPassword1">Confirm Password</label>
                  <input type="password" class="form-control" id="cexampleInputPassword1" >
                </div>
                 
                <button type="submit" class="btn btn-primary">Join The Event</button> -->
            <input class="d-none" name="bot-field">

             <h4 class="form-title"><strong>
                <center>Ticket Price :-</center>
              </strong> <br>
              <strong>
                <center>Non-IEEE member : INR 399</center>
              </strong><br>
              <strong>
                <center>IEEE member: INR 249</center>
              </strong>
            </h4>
            <div class="row">
              <div class="col-md-12">
                <div class="form-group d-flex align-items-center">
                  <label class="label" for="name"><strong>Full Name</strong></label>
                  <input type="text" class="form-control" placeholder="Full Name" name="Name">
                </div>
              </div>
              <div class="col-md-12">
                <div class="form-group d-flex align-items-center">
                  <label class="label" for="email"><strong>Email Address</strong> </label>
                  <input type="text" class="form-control" placeholder="username@gmail.com" name="Email 
                  id">
                </div>
              </div>
              <div class="col-md-12">
                <div class="form-group d-flex align-items-center">
                  <label class="label" for="phone"><strong>Phone no.</strong></label>
                  <input type="text" class="form-control" placeholder="+91" name="Phone">
                </div>
              </div>
              <div class="col-md-12">
                <div class="form-group d-flex align-items-center">
                  <label class="label" for="currentyear"><strong>Current Year</strong></label>
                  <input type="text" class="form-control" placeholder="1st" name="Current year">
                </div>
              </div>
              <div class="col-md-12">
                <div class="form-group d-flex align-items-center">
                  <label class="label" for="department"><strong>Department&emsp;</strong></label>
                  <input type="text" class="form-control" placeholder="Your Department" name="Dept">
                </div>
              </div>
              
              <div class="form-group">
                <center><h4><span class="badge badge-pill bg-light"><p> Are you an IEEE member?</h4></center>
                 
                  &emsp;&emsp;&emsp;
                  <input type="radio" name="IEEE MEM" value="yes" onclick="ShowHideDiv(this)" class="IEEE" required
                    name="Yes">&emsp;Yes&emsp;&emsp;
                    &emsp;&emsp;&emsp;
                  
                  <input type="radio" name="IEEE MEM" value="no" onclick="ShowHideDiv(this)" class="IEEE" required
                    name="no"> &emsp;No&emsp;&emsp;
                  </br></span>
                


                </p>
              </div>

              <div class="form-group" id="dvPassport">
                
                <h4><span class="badge badge-pill bg-light">(If "YES" enter IEEE Membership ID else leave blank):</span></h4>
                <center><input type="text" id="IEEE ID" class="IEEE ID" name="IEEE ID" /></center>
              </div>

              <div class="form-group">
                <h4><span class="badge badge-pill bg-light"><p> Do you favour Veg or Non-Veg?</h4>
                
                  &emsp;&emsp;&emsp;
                  <input type="radio" name="Food" value="Veg" required> &emsp;Veg &emsp;&emsp;
                  &emsp;&emsp;&emsp;
                  <input type="radio" name="Food" value="Non-Veg" required> &emsp;Non-Veg &emsp;&emsp;
                </p>
              </div>

               <!-- <label for="pet-select">Choose a pet:</label>  -->
              &emsp;&emsp;&emsp;&emsp;
              <div class="form-group">
                <h4><span class="badge badge-pill bg-light"><p> Select Your T-Shirt Size</h4>
                
                  <br>
                  &emsp;&emsp;<input type="radio" name="T-Shirt Size" value="M" required> &emsp;M <br>
                  &emsp;&emsp;<input type="radio" name="T-Shirt Size" value="L" required> &emsp;L </br>
                  &emsp;&emsp;<input type="radio" name="T-Shirt Size" value="XL" required>&emsp; XL </br>
                  &emsp;&emsp;<input type="radio" name="T-Shirt Size" value="XXL" required>&emsp;XXL </br>
                </p>
              </div>


              <div class="col-md-12 my-4">
                <div class="form-group">
                  <div class="w-100">
                    <label class="checkbox-wrap checkbox-primary"><strong>I agree all statements in terms of service</strong>
                      <input type="checkbox" checked>
                      <span class="checkmark"></span>
                    </label>
                  </div>
                </div>
              </div>
              <div class="col-md-12">
                <div class="form-group">
                  <center><button type="submit" class="btn btn-primary submit p-3">Register</button></center>
                </div>
              </div>
            </div> 

            <img src="ieee.png" style="width:20px;" class="d-block w-100" alt="...">
            <img src="merch2.png" style="width:20px;" class="d-block w-100" alt="...">

          </form> 
          


        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        </div>
      </div>
    </div>
  </div>
  <div id="carouselExampleCaptions" class="carousel slide carousel-fade" data-ride="carousel">
    <ol class="carousel-indicators">
      <li data-target="#carouselExampleCaptions" data-slide-to="0" class="active"></li>
      <li data-target="#carouselExampleCaptions" data-slide-to="1"></li>
      <li data-target="#carouselExampleCaptions" data-slide-to="2"></li>
    </ol>
    <div class="carousel-inner">
      <div class="carousel-item active">
        <img src="11.jpg" style="width:200px;" class="d-block w-100" alt="...">
        <div class="carousel-caption d-none d-md-block">
          <h2>Welcome to ML Acclerator 2.0</h2>
          <p>The Biggest flagship offline event of Jadavpur University </p>
          <button class="btn btn-danger">Learn</button>
          <button class="btn btn-primary">UpSkill</button>
          <button class="btn btn-success">Build</button>
          <button class="btn btn-warning">Fun</button>
        </div>
      </div>
      <div class="carousel-item">
        <img src="15.jpg" class="d-block w-100" alt="...">
        <div class="carousel-caption d-none d-md-block">
          <h2>Kickstart the Journey of ML with us</h2>
          <p>Learn ML and Data Science</p>
          <button class="btn btn-danger">Learn</button>
          <button class="btn btn-primary">UpSkill</button>
          <button class="btn btn-success">Build</button>
          <button class="btn btn-warning">Fun</button>
        </div>
      </div>
      <div class="carousel-item">
        <img src="4.jpg" class="d-block w-100" alt="...">
        <div class="carousel-caption d-none d-md-block">
          <h2>Sessions by the Best in the Industry</h2>
          <p>Fasten your Seatbelts to Enter the World of ML</p>
          <button class="btn btn-danger">Learn</button>
          <button class="btn btn-primary">UpSkill</button>
          <button class="btn btn-success">Build</button>
          <button class="btn btn-warning">Fun</button>
        </div>
      </div>
    </div>
    <a class="carousel-control-prev" href="#carouselExampleCaptions" role="button" data-slide="prev">
      <span class="carousel-control-prev-icon" aria-hidden="true"></span>
      <span class="sr-only">Previous</span>
    </a>
    <a class="carousel-control-next" href="#carouselExampleCaptions" role="button" data-slide="next">
      <span class="carousel-control-next-icon" aria-hidden="true"></span>
      <span class="sr-only">Next</span>
    </a>
  </div>

  <div class="p-3 mb-2 bg-dark bg-gradient text-white">
    <h3 class="text-center"><button type="button" class="btn btn-light"><strong>INSIGHTS</strong> </button></h3>
    <div class="container my-4">
      <div class="row mb-2">
        <div class="col-md-6">
          <div
            class="row no-gutters border rounded overflow-hidden flex-md-row mb-4 shadow-sm h-md-250 position-relative">
            <div class="col p-4 d-flex flex-column position-static">
              <strong class="d-inline-block mb-2 text-light">Our Speaker</strong>
              <h3 class="mb-0">Krishnachur Ghosh</h3>
              <h5 class="mb-0">SWE,MobileWalla</h5>
              <div class="mb-1 text-muted">JU Alumni</div>
              <p class="card-text mb-auto">Our ML Expert for the day</p>
              <a href="https://www.linkedin.com/in/krisg04/" class="card-link">Contact</a>
            </div>
            <div class="col-auto d-none d-lg-block">
              <img class="bd-placeholder-img" width="250" height="250" src="krish.jpg" alt="">
            </div>
          </div>
        </div>
        <div class="col-md-6">
          <div
            class="row no-gutters border rounded overflow-hidden flex-md-row mb-4 shadow-sm h-md-250 position-relative">
            <div class="col p-4 d-flex flex-column position-static">
              <strong class="d-inline-block mb-2 text-success">Our Sponsors</strong>
              <h3 class="mb-0">IEEE JUSB</h3>
              <h5 class="mb-0">JU Alumni, FETSU</h5>
              <div class="mb-1 text-muted">Capgemini</div>
              <p class="mb-auto">Supported by Ministry of Education</p>
              <a href="https://www.capgemini.com/careers/" class="card-link">Capgemini</a>

            </div>
            <div class="col-auto d-none d-lg-block">
              <img class="bd-placeholder-img" width="200" height="250" src="ju.png" alt="">

            </div>
          </div>
        </div>
      </div>
      <div class="row mb-2">
        <div class="col-md-6">
          <div
            class="row no-gutters border rounded overflow-hidden flex-md-row mb-4 shadow-sm h-md-250 position-relative">
            <div class="col p-4 d-flex flex-column position-static">
              <strong class="d-inline-block mb-2 text-danger">Prizes</strong>
              <h3 class="mb-0">Cool prizes and gifts for Winners</h3>
              <div class="mb-1 text-muted">worth 1000s</div>
              <p class="card-text mb-auto">Winner gets a Brand new AMAZON ECHO DOT worth Rs 5000/-</p>
              <p class="card-text mb-auto">Runners Up gets a Brand new Boat Echodots worth Rs 2000/-</p>
              <a href="#" class="stretched-link">Participate and Win prizes</a>
            </div>
            <div class="col-auto d-none d-lg-block">
              <img class="bd-placeholder-img" width="300" height="370" src="prize.png" alt="">
            </div>
          </div>
        </div>
        <div class="col-md-6">
          <div
            class="row no-gutters border rounded overflow-hidden flex-md-row mb-4 shadow-sm h-md-250 position-relative">
            <div class="col p-4 d-flex flex-column position-static">
              <strong class="d-inline-block mb-2 text-warning">Merchandise</strong>
              <h3 class="mb-0">Our Flagship level merch</h3>
              <div class="mb-1 text-muted">Lets go</div>
              <p class="mb-auto">Get our Premium merchandise worth RS 499/- for free</p>
              <a href="#" class="stretched-link">Get it now</a>
            </div>
            <div class="col-auto d-none d-lg-block">
              <img class="bd-placeholder-img" width="350" height="350" src="merch1.png" alt="">

            </div>
          </div>
        </div>
      </div>
      <section id="about" class="about">
        <br>
        <br>
        <h3 class="text-center"><button type="button" class="btn btn-light"><strong>ABOUT THE EVENT</strong> </button>
        </h3>
        <p>The Machine Learning Accelerator Summit is a tiny step taken by the IEEE Student Branch, Jadavpur University
          to help students, engineers and tech enthusiasts live the AI dream. This is a one-day hands-on workshop cum
          tech talk and a lot more. We look forward to decode the most sought-after concept in today's world, down to
          the very fundamentals.</p>
        <br>
        <br>
        <!-- <img src="about.png" style="  width: 700px;"> -->
        <section class="footer">
          <div class="footer_row">
            <div class="footer_column">
              <div class="ieee_info">
                <div class="text-center">
                  <img src="iee.png" style="width: 200px;">
                  <p>The Jadavpur University IEEE student branch, founded in 2010, belongs to the Kolkata section of
                    Region 10 of the organization. We are a group of enthusiastic students who are promoting innovative
                    ideas both within and outside the campus.</p>
                </div>
              </div>
            </div>

          </div>
        </section>
      </section>
      <!-- Glimpses  -->

      <br>
      <br>
      <section id="glimpses" class="glimpses">
        <h3 class="text-center"><button type="button" class="btn btn-light"><strong>GLIMPSES OF OUR PAST EVENTS</strong>
          </button></h3>
        <div id="carouselExampleDark" class="carousel carousel-dark slide" data-bs-ride="carousel">
          <div class="carousel-indicators">
            <button type="button" data-bs-target="#carouselExampleDark" data-bs-slide-to="0" class="active"
              aria-current="true" aria-label="Slide 1"></button>
            <button type="button" data-bs-target="#carouselExampleDark" data-bs-slide-to="1"
              aria-label="Slide 2"></button>
            <button type="button" data-bs-target="#carouselExampleDark" data-bs-slide-to="2"
              aria-label="Slide 3"></button>
          </div>
          <div class="carousel-inner">
            <div class="carousel-item active" data-bs-interval="10000">
              <img src="g2.jpg" class="d-block w-100" alt="...">
              <div class="carousel-caption d-none d-md-block">
                <h5>Last year's Event memories</h5>
                <p>Its time to create ours now.</p>
              </div>
            </div>
            <div class="carousel-item" data-bs-interval="2000">
              <img src="g1.jpg" class="d-block w-100" alt="...">
              <div class="carousel-caption d-none d-md-block">
                <h5>Lets Kickstart learning ML</h5>
                <p>Solve real life problems using ML</p>
              </div>
            </div>
            <div class="carousel-item">
              <img src="g3.jpg" class="d-block w-100" alt="...">
              <div class="carousel-caption d-none d-md-block">
                <h5>Explore ML in a unique way</h5>
                <p>Lets Go</p>
              </div>
            </div>
          </div>
          <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleDark"
            data-bs-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Previous</span>
          </button>
          <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleDark"
            data-bs-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Next</span>
          </button>
        </div>
      </section>
      <br>
      <br>
      <br>
      <!-- Event Venue -->
      <section id="venue" class="venue">
        <h3 class="text-center"><button type="button"
            class="btn btn-light"><strong><strong><strong>VENUE</strong></strong></strong> </button></h3>



        <div class="event_col">
          <div class="text-center">
            <h2>Jadavpur University, Kolkata</h2>
            <p>TEQUIP BULIDING room no 209 <br>
              Ph: 2457 - 2227 <br>
              Address <br>
              188, Raja S.C. Mallick Rd, <br>
              Kolkata 700032.Ph:+9133-24146666</p>
          </div>
        </div>
        <div class="event_col">
          <div class="text-center">
            <iframe
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3686.141139743283!2d88.36922361427233!3d22.498887141343925!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3a0271237f28abe9%3A0xd047bab0c8bfb11c!2sJadavpur%20University!5e0!3m2!1sen!2sin!4v1627026494040!5m2!1sen!2sin"
              width="300px" height="450" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
          </div>
        </div>
        <br>
        <br>
        <!-- <h3 class="text-center">For latest and fastest update Follow us on our Social media Handles</h3> -->
        <h3 class="text-center"><button type="button" class="btn btn-light"><strong>
              <h3 class="text-center">For latest and fastest update Follow us on our Social media Handles</h3>
            </strong> </button></h3>
        <link rel="stylesheet"
          href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

        <!-- Add font awesome icons -->
        <!-- <a href="#" class="fa fa-facebook"></a> -->
        <!-- <i class="fa fa-facebook-f" style="font-size:80px;color:aqua"></i> -->
        <!-- <a href="#" class="fa fa-linkedin"></a> -->
        <!-- i class="fa fa-linkedin" style="font-size:80px;color:aqua"></i> -->
        <br>
        <center>
          <a href="https://www.linkedin.com/company/ieee-ju/" class="fa fa-linkedin"
            style="font-size: 50px ;"></a>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;
          <a href="https://www.facebook.com/ieeejusb/" class="fa fa-facebook"
            style="font-size: 50px;"></a>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;
          <a href="https://instagram.com/_ieeeju?igshid=YmMyMTA2M2Y=" class="fa fa-instagram"
            style="font-size: 50px;"></a><br>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;
        </center>
        <br>
        <br>
        <br>
        <section id="contact" class="contact">
          <h3 class="text-center">For any Queries CONTACT US</h3>
          <div class="container my-4">
            <div class="row mb-2">
              <div class="col-md-6">
                <div
                  class="row no-gutters border rounded overflow-hidden flex-md-row mb-4 shadow-sm h-md-250 position-relative">
                  <div class="col p-4 d-flex flex-column position-static">
                    <strong class="d-inline-block mb-2 text-warning">OUR CHAIRPERSON</strong>
                    <h3 class="mb-0">Subhadip Nandy</h3>
                    <h5 class="mb-0">Intern at PWC India</h5>
                    <div class="mb-1 text-muted">JU IEE'23</div>
                    <p class="card-text mb-auto"></p>
                    <a href="https://www.linkedin.com/in/subhadip01nandy/" class="card-link">Contact</a>
                  </div>
                  <div class="col-auto d-none d-lg-block">
                    <img class="bd-placeholder-img" width="250" height="250" src="subhadip.jpg" alt="">
                  </div>
                </div>
              </div>

              <div class="col-md-6">
                <div
                  class="row no-gutters border rounded overflow-hidden flex-md-row mb-4 shadow-sm h-md-250 position-relative">
                  <div class="col p-4 d-flex flex-column position-static">
                    <strong class="d-inline-block mb-2 text-warning">OUR SECRATARY</strong>
                    <h3 class="mb-0">Biparnak Roy</h3>
                    <h5 class="mb-0">Intern at Wells Fargo</h5>
                    <div class="mb-1 text-muted">JU IEE'23</div>
                    <p class="mb-auto"></p>
                    <a href="https://www.linkedin.com/in/biparnak-roy-b32b34a8/" class="card-link">Contact</a>

                  </div>
                  <div class="col-auto d-none d-lg-block">
                    <img class="bd-placeholder-img" width="200" height="250" src="biparnak.jpg" alt="">

                  </div>
                </div>
              </div>
              <div class="col-md-6">
                <div
                  class="row no-gutters border rounded overflow-hidden flex-md-row mb-4 shadow-sm h-md-250 position-relative">
                  <div class="col p-4 d-flex flex-column position-static">
                    <strong class="d-inline-block mb-2 text-warning">OUR VICE CHAIRPERSON</strong>
                    <h3 class="mb-0">Debojit Ghosh</h3>
                    <h5 class="mb-0"></h5>
                    <div class="mb-1 text-muted">JU IEE'23</div>
                    <p class="mb-auto"></p>
                    <a href="https://www.linkedin.com/in/debojitghosh/" class="card-link">Contact</a>

                  </div>
                  <div class="col-auto d-none d-lg-block">
                    <img class="bd-placeholder-img" width="250" height="250" src="debojit.jpg" alt="">

                  </div>
                </div>
              </div>
              <div class="col-md-6">
                <div
                  class="row no-gutters border rounded overflow-hidden flex-md-row mb-4 shadow-sm h-md-250 position-relative">
                  <div class="col p-4 d-flex flex-column position-static">
                    <strong class="d-inline-block mb-2 text-warning">OUR CHAIRMAN</strong>
                    <h3 class="mb-0">Shreya Biswas</h3>
                    <h5 class="mb-0">Intern at MIR labs</h5>
                    <div class="mb-1 text-muted">JU ETCE'23</div>
                    <p class="mb-auto"></p>
                    <a href="" class="card-link">Contact</a>

                  </div>
                  <div class="col-auto d-none d-lg-block">
                    <img class="bd-placeholder-img" width="250" height="250" src="shreya.jpg" alt="">

                  </div>
                </div>
              </div>
        </section>
        <section class="footer2">
          <div class="text-center">
            <p>Made by Subham Sinha, JU IEE'25. ©2022</p>
          </div>
        </section>
    </div>
    <script>
      var navLink = document.getElementById("navLink");
      function hideMenu() {
        navLink.style.right = "-200px";
      }
      function showMenu() {
        navLink.style.right = "0";
      }
    </script>
    <!-- for scrolling animation -->
    <script src="https://unpkg.com/aos@next/dist/aos.js"></script>
    <script>
      AOS.init({
        offset: 160,
        duration: 800
      });
    </script>
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js"
      integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n"
      crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"
      integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo"
      crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"
      integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6"
      crossorigin="anonymous"></script>
</body>
<!-- </div> -->

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
  </body>
</html>
