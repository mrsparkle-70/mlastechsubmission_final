config.php - configuration database
login.php -login
register.php  - allows user to login
welcome.php -redirect
logout.php - logout